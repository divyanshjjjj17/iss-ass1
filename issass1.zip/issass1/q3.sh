wc -c quotes.txt
   10640 quotes.txt

