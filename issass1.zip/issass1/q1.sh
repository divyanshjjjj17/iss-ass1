sort quotes.txt | uniq -i
